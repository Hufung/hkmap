import type { 
    Carpark, 
    AttractionFeature, 
    ViewingPointFeature, 
    ParkingMeterFeature, 
    TurnRestrictionFeature,
    TrafficFeature,
    PermitFeature,
    ProhibitionFeature,
    Language 
} from '../types';
import { 
    API_INFO_BASE_URL, 
    API_VACANCY_BASE_URL, 
    API_ATTRACTIONS_URL, 
    API_VIEWING_POINTS_URL, 
    API_PARKING_METERS_BASE_URL,
    API_PARKING_METERS_STATUS_URL,
    API_TURN_RESTRICTIONS_URL,
    API_TRAFFIC_FEATURES_BASE_URL,
    API_PERMIT_URL,
    API_PROHIBITION_PC_URL,
    API_PROHIBITION_ALL_URL
} from '../constants';

// --- Car Parks ---
export async function fetchCarparkData(lang: Language): Promise<Carpark[]> {
    const langParam = `&lang=${lang}`;
    const infoUrl = API_INFO_BASE_URL + langParam;
    const infoResponse = await fetch(infoUrl);
    if (!infoResponse.ok) throw new Error('Failed to fetch car park info.');
    const infoData = await infoResponse.json();
    const infoList = infoData.results || [];

    if (infoList.length === 0) return [];

    const parkIds = infoList.map((park: Carpark) => park.park_Id).join(',');
    const vacancyUrl = `${API_VACANCY_BASE_URL}&carparkIds=${parkIds}${langParam}`;
    const vacancyResponse = await fetch(vacancyUrl);
    let vacancyList = [];
    if (vacancyResponse.ok) {
        const vacancyData = await vacancyResponse.json();
        vacancyList = vacancyData.results || [];
    } else {
        console.error('Failed to fetch car park vacancy data.');
    }

    const vacancyMap = new Map();
    for (const vacancy of vacancyList) {
        vacancyMap.set(vacancy.park_Id, vacancy);
    }
    return infoList.map((info: Carpark) => ({
        ...info,
        vacancyData: vacancyMap.get(info.park_Id) || null
    }));
}

// --- Attractions ---
export async function fetchAttractionsData(): Promise<AttractionFeature[]> {
    const response = await fetch(API_ATTRACTIONS_URL);
    if (!response.ok) throw new Error('Failed to fetch attractions data.');
    const data = await response.json();
    return data.features || [];
}

// --- Viewing Points ---
export async function fetchViewingPointsData(): Promise<ViewingPointFeature[]> {
    const response = await fetch(API_VIEWING_POINTS_URL);
    if (!response.ok) throw new Error('Failed to fetch viewing points data.');
    const data = await response.json();
    return data.features || [];
}

// --- Parking Meters ---
let parkingMeterStatusCache: Map<string, string> | null = null;

function parseCSVToMap(csvText: string): Map<string, string> {
    const statusMap = new Map<string, string>();
    const rows = csvText.split('\n');
    for (let i = 1; i < rows.length; i++) {
        const columns = rows[i].split(',');
        if (columns.length >= 3) {
            const parkingSpaceId = columns[0];
            const occupancyStatus = columns[2];
            if (parkingSpaceId && parkingSpaceId.trim() !== "") {
                statusMap.set(parkingSpaceId.trim(), occupancyStatus.trim());
            }
        }
    }
    return statusMap;
}

export async function fetchInitialParkingMeterStatus(): Promise<Map<string, string>> {
    if (parkingMeterStatusCache) return parkingMeterStatusCache;
    try {
        const response = await fetch(API_PARKING_METERS_STATUS_URL);
        if (!response.ok) throw new Error('Failed to fetch parking meter status data.');
        const statusText = await response.text();
        parkingMeterStatusCache = parseCSVToMap(statusText);
        return parkingMeterStatusCache;
    } catch (error) {
        console.error("Error fetching parking meter status:", error);
        return new Map();
    }
}

export function getCachedParkingMeterStatus(): Map<string, string> {
    return parkingMeterStatusCache || new Map();
}

export async function fetchParkingMetersInBounds(bounds: L.LatLngBounds): Promise<ParkingMeterFeature[]> {
    const lowerCorner = `${bounds.getSouth()} ${bounds.getWest()}`;
    const upperCorner = `${bounds.getNorth()} ${bounds.getEast()}`;
    const filter = `<Filter><Intersects><PropertyName>SHAPE</PropertyName><gml:Envelope srsName='EPSG:4326'><gml:lowerCorner>${lowerCorner}</gml:lowerCorner><gml:upperCorner>${upperCorner}</gml:upperCorner></gml:Envelope></Intersects></Filter>`;
    const maxFeatures = 500;
    const locationUrl = `${API_PARKING_METERS_BASE_URL}&maxFeatures=${maxFeatures}&filter=${encodeURIComponent(filter)}`;

    const response = await fetch(locationUrl);
    if (!response.ok) throw new Error('Failed to fetch parking meter location data.');
    const data = await response.json();
    return data.features || [];
}

// --- Turn Restrictions ---
function parseKMLToGeoJSON(kmlText: string): { type: 'FeatureCollection'; features: TurnRestrictionFeature[] } {
    const parser = new DOMParser();
    const kmlDoc = parser.parseFromString(kmlText, 'text/xml');
    const placemarks = kmlDoc.querySelectorAll('Placemark');
    const features: TurnRestrictionFeature[] = [];

    placemarks.forEach(placemark => {
        const name = placemark.querySelector('name')?.textContent || '';
        const description = placemark.querySelector('description')?.textContent || '';
        const coordinates = placemark.querySelector('coordinates')?.textContent;

        if (coordinates) {
            const coords = coordinates.trim().split(',').map(c => parseFloat(c));
            if (coords.length >= 2) {
                features.push({
                    type: 'Feature',
                    geometry: {
                        type: 'Point',
                        coordinates: [coords[0], coords[1]] // lon, lat
                    },
                    properties: { name, description }
                });
            }
        }
    });

    return { type: 'FeatureCollection', features };
}

export async function fetchTurnRestrictionsData(): Promise<TurnRestrictionFeature[]> {
    try {
        const response = await fetch(API_TURN_RESTRICTIONS_URL);
        if (!response.ok) throw new Error('Failed to fetch turn restrictions KMZ data.');

        const kmzBlob = await response.blob();
        // @ts-ignore JSZip is loaded from CDN
        const zip = await JSZip.loadAsync(kmzBlob);
        
        const kmlFile = Object.keys(zip.files).find(fileName => fileName.endsWith('.kml'));
        if (!kmlFile) throw new Error('No KML file found in KMZ.');

        const kmlText = await zip.files[kmlFile].async('text');
        const geojsonData = parseKMLToGeoJSON(kmlText);
        return geojsonData.features;
    } catch(error) {
        console.error("Error fetching turn restrictions:", error);
        return [];
    }
}


// --- Traffic Features ---
export async function fetchTrafficFeaturesNearby(latlng: L.LatLng): Promise<TrafficFeature[]> {
    try {
        // Create a 3.5km bounding box around the user's location
        const buffer = 0.035; // Approx 3.5km in degrees
        const lowerCorner = `${latlng.lat - buffer} ${latlng.lng - buffer}`;
        const upperCorner = `${latlng.lat + buffer} ${latlng.lng + buffer}`;
        const filter = `<Filter><Intersects><PropertyName>SHAPE</PropertyName><gml:Envelope srsName='EPSG:4326'><gml:lowerCorner>${lowerCorner}</gml:lowerCorner><gml:upperCorner>${upperCorner}</gml:upperCorner></gml:Envelope></Intersects></Filter>`;
        
        const url = `${API_TRAFFIC_FEATURES_BASE_URL}&filter=${encodeURIComponent(filter)}`;

        const response = await fetch(url);
        if (!response.ok) throw new Error('Failed to fetch traffic features data.');
        const data = await response.json();
        return data.features || [];
    } catch (error) {
        console.error("Error fetching traffic features data:", error);
        return [];
    }
}

// --- Permits ---
export async function fetchPermitData(): Promise<PermitFeature[]> {
    try {
        const response = await fetch(API_PERMIT_URL);
        if (!response.ok) throw new Error('Failed to fetch permit data.');
        const data = await response.json();
        return data.features || [];
    } catch (error) {
        console.error("Error fetching permit data:", error);
        return [];
    }
}

// --- Prohibitions ---
export async function fetchProhibitionData(): Promise<ProhibitionFeature[]> {
    try {
        const [pcResponse, allResponse] = await Promise.all([
            fetch(API_PROHIBITION_PC_URL),
            fetch(API_PROHIBITION_ALL_URL)
        ]);

        if (!pcResponse.ok || !allResponse.ok) {
            console.error('Failed to fetch one or more prohibition datasets.');
            return [];
        }

        const pcData = await pcResponse.json();
        const allData = await allResponse.json();

        const combinedFeatures = [
            ...(pcData.features || []),
            ...(allData.features || [])
        ];
        
        return combinedFeatures;

    } catch (error) {
        console.error("Error fetching prohibition data:", error);
        return [];
    }
}