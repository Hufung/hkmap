import React, { useState, useEffect, useCallback } from 'react';
import type { Map as LeafletMap } from 'leaflet';
import type { 
    Carpark, 
    AttractionFeature, 
    ViewingPointFeature, 
    TurnRestrictionFeature, 
    PermitFeature,
    ProhibitionFeature,
    Language,
    VisibleLayers
} from './types';
import { 
    fetchCarparkData, 
    fetchAttractionsData, 
    fetchViewingPointsData, 
    fetchInitialParkingMeterStatus,
    fetchTurnRestrictionsData,
    fetchPermitData,
    fetchProhibitionData
} from './services/dataService';

import { MapComponent } from './components/MapComponent';
import { Header } from './components/Header';
import { LayerControl } from './components/LayerControl';
import { InfoModal } from './components/InfoModal';
import { LoadingSpinner } from './components/LoadingSpinner';
import { Legend } from './components/Legend';

const App: React.FC = () => {
    const [map, setMap] = useState<LeafletMap | null>(null);
    const [language, setLanguage] = useState<Language>('en_US');
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [carparkData, setCarparkData] = useState<Carpark[]>([]);
    const [attractionsData, setAttractionsData] = useState<AttractionFeature[]>([]);
    const [viewingPointsData, setViewingPointsData] = useState<ViewingPointFeature[]>([]);
    const [turnRestrictionsData, setTurnRestrictionsData] = useState<TurnRestrictionFeature[]>([]);
    const [permitData, setPermitData] = useState<PermitFeature[]>([]);
    const [prohibitionData, setProhibitionData] = useState<ProhibitionFeature[]>([]);
    const [navigationTarget, setNavigationTarget] = useState<{lat: number, lon: number} | null>(null);

    const [visibleLayers, setVisibleLayers] = useState<VisibleLayers>({
        carparks: true,
        attractions: false,
        viewingPoints: false,
        parkingMeters: false,
        permits: true,
        prohibitions: true,
    });
    
    const [selectedCarpark, setSelectedCarpark] = useState<Carpark | null>(null);

    const handleLanguageChange = (lang: Language) => {
        setIsLoading(true);
        setLanguage(lang);
    };

    const loadInitialData = useCallback(async () => {
        setIsLoading(true);
        try {
            const [
                carparks,
                attractions, 
                viewingPoints,
                turnRestrictions,
                permits,
                prohibitions,
            ] = await Promise.all([
                fetchCarparkData(language),
                fetchAttractionsData(),
                fetchViewingPointsData(),
                fetchTurnRestrictionsData(),
                fetchPermitData(),
                fetchProhibitionData(),
                fetchInitialParkingMeterStatus() // Fetches and caches status
            ]);

            setCarparkData(carparks);
            setAttractionsData(attractions);
            setViewingPointsData(viewingPoints);
            setTurnRestrictionsData(turnRestrictions);
            setPermitData(permits);
            setProhibitionData(prohibitions);
            
        } catch (error) {
            console.error("Failed to load initial data:", error);
        } finally {
            setIsLoading(false);
        }
    }, [language]);

    useEffect(() => {
        loadInitialData();
    }, [loadInitialData]);


    const handleMarkerClick = useCallback((carpark: Carpark) => {
        setSelectedCarpark(carpark);
    }, []);

    const handleCloseModal = () => {
        setSelectedCarpark(null);
    };

    const handleStartNavigation = useCallback((lat: number, lon: number) => {
        setNavigationTarget({ lat, lon });
    }, []);

    const handleNavigationStarted = useCallback(() => {
        setNavigationTarget(null); // Reset trigger
    }, []);
    
    return (
        <div className="font-sans antialiased relative overflow-hidden w-screen h-screen">
            <Header
                language={language}
                onLanguageChange={handleLanguageChange}
                onLocateUser={() => map?.locate({ setView: true, maxZoom: 16 })}
            />
            <LayerControl
                language={language}
                visibleLayers={visibleLayers}
                onVisibilityChange={setVisibleLayers}
            />
            <Legend language={language} />
            
            <MapComponent
                setMap={setMap}
                language={language}
                visibleLayers={visibleLayers}
                carparkData={carparkData}
                attractionsData={attractionsData}
                viewingPointsData={viewingPointsData}
                turnRestrictionsData={turnRestrictionsData}
                permitData={permitData}
                prohibitionData={prohibitionData}
                onMarkerClick={handleMarkerClick}
                navigationTarget={navigationTarget}
                onNavigationStarted={handleNavigationStarted}
            />
            
            {isLoading && <LoadingSpinner />}
            
            {selectedCarpark && (
                <InfoModal
                    carpark={selectedCarpark}
                    language={language}
                    onClose={handleCloseModal}
                    onNavigate={handleStartNavigation}
                />
            )}
        </div>
    );
};

export default App;